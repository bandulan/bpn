 </div>
 <!-- /.content-wrapper -->

 <footer class="main-footer">
   <div class="row">


     <div class="mx-auto">


       <strong>Copyright &copy; 2019 <a href="geolabsurvey.com/blog">Rezalendra</a>.</strong> All rights
       reserved.
     </div>
   </div>
 </footer>

 <!-- Control Sidebar -->
 <aside class="control-sidebar control-sidebar-dark">
   <!-- Control sidebar content goes here -->
 </aside>
 <!-- /.control-sidebar -->
 </div>
 <!-- ./wrapper -->

 <!-- jQuery -->
 <script src="../../bpn/lte/plugins/jquery/jquery.min.js"></script>
 <!-- Bootstrap 4 -->
 <script src="../../bpn/lte/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
 <!-- AdminLTE App -->
 <script src="../../bpn/lte/dist/js/adminlte.min.js"></script>
 <!-- AdminLTE for demo purposes -->
 <script src="../../bpn/lte/dist/js/demo.js"></script>
 <!-- data table -->


 <script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

 <script>
   $(document).ready(function() {
     $('#dataa').DataTable();
   });
 </script>
 </body>

 </html>